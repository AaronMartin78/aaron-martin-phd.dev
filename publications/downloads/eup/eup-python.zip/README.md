# Replication materials: eup

The Python port covers the data construction and selected statistical tables from the December 2020 replication files. Its saved reports do not establish complete reproduction of every published figure, table or appendix. See the included README and saved validation reports for scope and tolerances.

## Run the Python package

Extract the whole ZIP, retaining the directory structure. Python 3.10+ is recommended. From the extracted directory:

    python -m venv .venv
    # Activate the environment using the command for your operating system.
    python -m pip install -r requirements.txt
    cd EUP_Python_Replication
    python run_all.py

The bundled config paths point to reference/ for the original do-file and log; analysis code is unchanged. Read EUP_Python_Replication/README.md for additional validation commands and omissions. Existing output files and reports are historical results supplied with the port; they were not regenerated when packaging the downloads. The Party Politics R script needs R and lme4 and is not a verified final-publication replication.

## Data

CSV copies are unchanged from the author's converted-data folder. data-manifest.csv records the corresponding source Stata path, dimensions and SHA-256 digests. codebooks.json preserves variable labels and value-label definitions read from those originals. CSVs retain numeric category codes. Empty fields represent missing values; CSV does not preserve all Stata metadata or extended missing codes. Load using pandas.read_csv; Stata is not required. Treat identifiers as identifiers rather than measurements.

Some original Stata strings trigger pandas' documented UTF-8 to Latin-1 decoding fallback. The CSVs were compared to those decoded originals, including date and string values.

## Original Stata materials

The separate Stata ZIP contains archived .dta, .do and log files. The original code is unchanged and may need working-directory paths and Stata add-on commands configured. The March 2021 Party Politics archive is not certified as the final published replication package.

## Citation and reuse

Please cite Aaron R. Martin's corresponding article (DOI below) when using these materials and retain attribution to underlying data sources. No new blanket licence is assigned here to third-party inputs; see the article, original documentation and source conditions for their terms.

DOI: 10.1177/1465116521999718
