"""End-to-end EUP replication in Python.

Runs raw -> Stage A -> Stage B -> Stage C/D, then the Table 2 t-tests and the
Table 4 Firth logit models, writing all outputs to ./output/ and a validation
report comparing every stage against the original Stata datasets and log.

    python run_all.py
"""
import warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
from eup import config, stage_a, stage_b, stage_c, results

def _match(got, ref, rtol=1e-3, atol=1e-2):
    """fraction of matching cells across shared columns after key alignment"""
    shared = [c for c in ref.columns if c in got.columns]
    total = ok = 0
    for c in shared:
        a, b = got[c], ref[c]
        if a.dtype.kind in "fi" and b.dtype.kind in "fi":
            diff = (a.astype(float) - b.astype(float)).abs()
            rel = diff / b.astype(float).abs().replace(0, np.nan)
            m = (diff <= atol) | (rel <= rtol) | (a.isna() & b.isna())
        else:
            m = (a.astype("string") == b.astype("string")) | (a.isna() & b.isna())
        ok += int(m.sum()); total += len(a)
    return ok, total, len(shared)

def _align(got, ref, key):
    g = got.set_index(key).sort_index(); r = ref.set_index(key).sort_index()
    ix = g.index.intersection(r.index)
    return g.loc[ix], r.loc[ix]

def main():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    A = stage_a.run(raw)
    B = stage_b.run(A)
    C = stage_c.run(B)

    A.to_csv(config.OUT / "stage_A.csv", index=False)
    B.to_csv(config.OUT / "stage_B.csv", index=False)
    C.to_csv(config.OUT / "stage_C.csv", index=False)

    t2 = results.table2(C); t2.to_csv(config.OUT / "table2_ttests.csv", index=False)
    t4 = results.table4(B)  # 3 full + 4 constrained 'power' models
    rows = []
    for name, m in t4.items():
        for var, coef in m["coef"].items():
            rows.append(dict(model=name, term=var, coef=coef,
                             se=m["bse"].get(var, np.nan), n=m["n"], loglik=m["loglik"]))
    pd.DataFrame(rows).to_csv(config.OUT / "table4_firthlogit.csv", index=False)

    # Appendix B (McElroy)
    mc = pd.read_csv(config.CONVERTED / "McElroy_replication_data.csv", low_memory=False)
    ab = results.appendix_b(mc)
    ab_rows = [dict(model=name, term=k, coef=v, se=m["bse"].get(k, np.nan), n=m["n"], loglik=m["loglik"])
               for name, m in ab.items() for k, v in m["coef"].items()]
    pd.DataFrame(ab_rows).to_csv(config.OUT / "appendixB_mcelroy.csv", index=False)

    # --- validation ---
    lines = ["# EUP replication - validation report", ""]
    refA = pd.read_csv(config.STAGE_A_REF, low_memory=False)
    refB = pd.read_csv(config.STAGE_B_REF, low_memory=False)
    refC = pd.read_csv(config.STAGE_C_REF, low_memory=False)
    for label, got, ref, key in [
        ("Stage A", A, refA, ["hoy_id","EP","start_group","end_group"]),
        ("Stage B", B, refB, ["hoy_id","EP","start_group","end_group","bloc_id"]),
        ("Stage C", C, refC, ["EP","start_group"]),
    ]:
        g, r = _align(got, ref, key)
        ok, tot, ncol = _match(g, r)
        lines.append(f"{label}: {ok}/{tot} cells match across {ncol} columns "
                     f"({len(g)} rows)  ->  {100*ok/tot:.3f}%")
    lines.append("")
    lines.append("## Table 4 Firth logit (vs replication_log.log)")
    truth = {"all_switch_full": (3962, -637.68894),
             "indiv_switch_full": (3962, -455.84114),
             "bloc_switch_full": (3962, -326.97514)}
    for name, m in t4.items():
        N, LL = truth[name]
        lines.append(f"  {name:18s} N={m['n']} (stata {N})  logLik*={m['loglik']:.5f} (stata {LL})")

    (config.OUT / "validation_report.md").write_text("\n".join(lines))
    print("\n".join(lines))
    print(f"\nOutputs written to {config.OUT}")

if __name__ == "__main__":
    main()
