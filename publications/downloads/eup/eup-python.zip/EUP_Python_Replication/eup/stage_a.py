"""Stage A: raw EUP replication dataset -> _A.

Ports lines 46-1932 of Replication_Code_12102020.do.

For every European Parliament party group the original code repeats one
computation: within each session (EP), split the group's member-sessions into
national-party delegations (bloc_id), then compute
  - concentration = sum_over_delegations( (share*100)^2 )   [HHI, 0-10000]
  - enp          = 10000 / concentration                    [Laakso-Taagepera]
  - epg_perc     = group members / session_total_members    [seat share]
  - npd_per_epg  = number of delegations
  - npd_percent  = delegation share (per row)
Groups are processed in the exact do-file order; a member-session belonging to
several groups is overwritten by the last group processed (this is faithful to
the Stata `replace ... if <group>_check==1` sequence).

Each group also carries hand corrections (bloc_id reassignments, delegation
exclusions, hard-coded counts) transcribed verbatim from the do file.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
GROUP_CODE_COLS = ["start_group_ses", "start_group", "group1_ses", "group2_ses", "group3_ses"]
GROUP_NUM_COLS  = ["start_group_num_ses", "start_group_num", "group1_num_ses", "group2_num_ses", "group3_num_ses"]


def _code_mask(df: pd.DataFrame, code: str) -> pd.Series:
    m = pd.Series(False, index=df.index)
    for c in GROUP_CODE_COLS:
        m |= (df[c].astype("string") == code)
    return m.fillna(False)


def _num_mask(df: pd.DataFrame, num: int) -> pd.Series:
    m = pd.Series(False, index=df.index)
    for c in GROUP_NUM_COLS:
        m |= (df[c] == num)
    return m.fillna(False)


def compute_group(df, chk, *,
                  write_enp=True, write_conc=True, write_enp3=True,
                  set_members=True, set_npd=True, set_seat=True, set_npct=True,
                  seat_eps=None, npd_eps=None,
                  excluded_blocs=None, xx_override=None, yy2_override=None):
    """Run the canonical delegation computation for one group.

    chk            boolean Series: rows where the group is present in a session.
    seat_eps/npd_eps  restrict epg_perc / npd_per_epg writes to these EPs (None=all).
    excluded_blocs {ep: [bloc_id,...]} delegations kept in the denominator (xx)
                   but excluded from the delegation count and concentration
                   (Stata `replace tag = 0 ...`).
    xx_override / yy2_override  {ep: value} force the member count / delegation
                   count for that EP (Stata `replace xx = ..` / `replace yy2 = ..`).
    """
    excluded_blocs = excluded_blocs or {}
    xx_override = xx_override or {}
    yy2_override = yy2_override or {}
    for ep in sorted(df.loc[chk, "EP"].dropna().unique()):
        m = chk & (df["EP"] == ep)
        sub = df.loc[m]
        if len(sub) == 0:
            continue
        # concentration & delegation count use TAGGED rows only; Stata does not
        # tag missing bloc_id, so exclude NaN here (dropna=True).
        sizes = sub.groupby("bloc_id").size()            # yy per non-missing delegation
        xx = xx_override.get(ep, len(sub))               # member-sessions
        excl = set(excluded_blocs.get(ep, []))
        counted = sizes[~sizes.index.isin(excl)]         # delegations kept in concentration
        # exclusions (Stata tag=0) apply AFTER yy2 is finalised, so they lower
        # concentration but NOT the delegation count.
        ndeleg = yy2_override.get(ep, sizes.size)
        hhi = (((counted / xx) * 100) ** 2).sum()
        enp = 10000.0 / hhi if hhi > 0 else np.nan
        stm = sub["session_total_members"].iloc[0]
        seat = xx / stm
        if write_conc:
            df.loc[m, "concentration"] = hhi
        if write_enp:
            df.loc[m, "enp"] = enp
        if write_enp3:
            df.loc[m, "enp3"] = enp                      # enp2 == enp
        if set_members:
            df.loc[m, "epg_members"] = xx
        if set_npct:
            row_yy = sub.groupby("bloc_id", dropna=False)["EP"].transform("size")
            df.loc[m, "npd_percent"] = row_yy / xx
        if set_seat and (seat_eps is None or ep in seat_eps):
            df.loc[m, "epg_perc"] = seat
        if set_npd and (npd_eps is None or ep in npd_eps):
            df.loc[m, "npd_per_epg"] = ndeleg


def ftr(df, chk, founding_ep, *, npds_epgtag=False):
    """Failed-to-reform lagged variables for a collapsing group.

    Each ftr_* variable = the group-level value in its founding session,
    broadcast to every member-session of the group.
    """
    def lag(col, cond=None):
        rows = chk & (df["EP"] == founding_ep)
        if cond is not None:
            rows = rows & cond
        vals = df.loc[rows, col]
        return vals.max() if len(vals) else 0.0
    df.loc[chk, "ftr_epg_days"] = lag("epg_days")
    df.loc[chk, "ftr_epg_ts"]   = lag("tenure_raw2")
    df.loc[chk, "ftr_epg_perc"] = lag("epg_perc")
    npd_cond = (df["epg_tag"] == 1) if npds_epgtag else None
    df.loc[chk, "ftr_npds"]     = lag("npd_per_epg", npd_cond)
    df.loc[chk, "ftr_concent"]  = lag("concentration")
    df.loc[chk, "ftr_enp"]      = lag("enp")


# ----------------------------------------------------------------------------
# stage A driver
# ----------------------------------------------------------------------------
DATE_COLS = ["switch_date1", "switch_date2", "switch_date3", "switch_date4",
             "start_date_ses", "end_date_ses"]
_EPOCH = pd.Timestamp("1960-01-01")


def run(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()

    # Stata stores dates as integer days since 1960-01-01; the CSV holds ISO
    # strings. Convert so date arithmetic yields day counts like the do file.
    for c in DATE_COLS:
        if c in df:
            df[c] = (pd.to_datetime(df[c], errors="coerce") - _EPOCH).dt.days

    # --- initialisation (do lines 48-52) ---
    df["enp"] = 0.0
    df["enp3"] = 0.0
    df["term_share"] = 0.0
    df.loc[df["tenure_raw2"] >= 1, "term_share"] = df["tenure_raw2"]
    df["npd_percent"] = 0.0
    for c in ["ftr_epg_days", "ftr_epg_ts", "ftr_epg_perc", "ftr_npds", "ftr_concent", "ftr_enp"]:
        df[c] = np.nan
    # *_check columns are recorded for reference/validation
    checks = {}

    def rec(name, mask):
        df[name] = mask.astype(int)
        checks[name] = mask

    # ===== CDI (EP1 founding) =====
    chk = _code_mask(df, "CDI"); rec("cdi_check", chk)
    compute_group(df, chk, set_members=False, seat_eps={1}, npd_eps={1})
    ftr(df, chk, 1)

    # ===== DEP (EP1) npd hard-coded 5 =====
    chk = _code_mask(df, "DEP"); rec("dep_check", chk)
    compute_group(df, chk, set_members=False, seat_eps={1}, set_npd=False)
    df.loc[chk & (df.EP == 1), "npd_per_epg"] = 5
    ftr(df, chk, 1)

    # ===== TCDI (EP2) npd 6 =====
    chk = _code_mask(df, "TCDI"); rec("tcdi_check", chk)
    df.loc[chk & (df.EP == 2), "term_share"] = df["tcdi_days"] / df["max_EP2_days"]
    compute_group(df, chk, set_members=False, seat_eps={2}, set_npd=False)
    df.loc[chk & (df.EP == 2), "npd_per_epg"] = 6

    # ===== COM (EP2 founding) =====
    df.loc[(df.EP == 3) & (df.hoy_id == 1277), "nationalparty"] = "Socialistisk folkeparti"
    chk = _code_mask(df, "COM"); rec("com_check", chk)
    compute_group(df, chk)
    ftr(df, chk, 2)

    # ===== ED (EP3) heavy hand-forcing =====
    df.loc[(df.bloc_id == 253) & (df.EP == 3) & _code_mask(df, "ED"), "bloc_id"] = 240
    chk = _code_mask(df, "ED"); rec("ed_check", chk)
    df["ed_days"] = 0.0
    df.loc[chk, "ed_days"] = df["switch_date1"] - df["start_date_ses"]
    df.loc[chk & (df.EP == 3), "term_share"] = 2 + df["ed_days"] / df["max_EP3_days"]
    df.loc[(df.EP == 1) & (df.start_group == "ED") & (df.hoy_id == 765), "epg_tag"] = 1
    df.loc[(df.EP == 2) & chk & (df.hoy_id == 1651) & (df.epg_tag == 1), "epg_tag"] = 0
    compute_group(df, chk, xx_override={3: 34}, yy2_override={3: 2}, excluded_blocs={3: [240]})
    df.loc[chk & (df.EP == 3) & (df.epg_tag == 1), "term_share"] = 2.5558

    # ===== GUE (EP3) mid-session collapse epg_days =====
    chk = _code_mask(df, "GUE"); rec("gue_check", chk)
    df.loc[chk & (df.EP == 3) & (df.hoy_id == 947), "epg_tag"] = 1
    df["marker"] = np.where(chk & df["switch_date2"].notna(), 1.0, np.nan)
    df["mm"] = np.where(df["marker"] == 1, df["switch_date2"] - df["start_date_ses"], np.nan)
    mmm = df.loc[chk & (df.EP == 3), "mm"].max()
    df.loc[chk & (df.EP == 3), "epg_days"] = mmm
    df["gue_days"] = 0.0
    df.loc[chk, "gue_days"] = df["switch_date2"] - df["start_date_ses"]
    df.loc[chk & (df.EP == 3), "term_share"] = df["epg_days"] / df["max_EP3_days"]
    compute_group(df, chk)

    # ===== CG (EP3) =====
    chk = _code_mask(df, "CG"); rec("cg_check", chk)
    compute_group(df, chk)
    ftr(df, chk, 3)

    # ===== DR (EP3) =====
    chk = _code_mask(df, "DR"); rec("dr_check", chk)
    compute_group(df, chk)
    ftr(df, chk, 3)

    # ===== FE (EP4) =====
    m_fe = _code_mask(df, "FE")
    df.loc[(df.bloc_id == 372) & (df.EP == 4) & (df.ms == "IT") & (df.end_group_ses == "EPP") & m_fe, "bloc_id"] = 373
    df.loc[(df.bloc_id == 395) & (df.EP == 4) & (df.ms == "IT") & (df.end_group_ses == "EPP") & m_fe, "bloc_id"] = 373
    chk = _code_mask(df, "FE"); rec("fe_check", chk)
    df["fe_days"] = 0.0
    df.loc[chk & (df.start_group_ses == "FE"), "fe_days"] = df["switch_date1"] - df["start_date_ses"]
    df.loc[chk & (df.EP == 4), "term_share"] = df["fe_days"] / df["max_EP4_days"]
    df.loc[chk & (df.EP == 4) & (df.term_share == 0), "term_share"] = 0.1922234
    compute_group(df, chk)

    # ===== RBW (EP3) =====
    chk = _code_mask(df, "RBW")
    chk = chk & ~((chk) & (df.EP == 3) & (df.group1_ses == "V") & (df.group2_ses == "."))
    rec("rbw_check", chk)
    compute_group(df, chk)
    ftr(df, chk, 3)

    # ===== UPE (EP4) mid-session; term_share hard-coded =====
    df.loc[(df.bloc_id == 395) & (df.EP == 4) & (df.nationalparty == "Centro cristiano democratico"), "bloc_id"] = 372
    df.loc[(df.bloc_id == 379) & (df.EP == 4) & (df.parlgov_partyid == 658), "bloc_id"] = 375
    df.loc[(df.bloc_id == 380) & (df.EP == 4) & (df.parlgov_partyid == 251), "bloc_id"] = 377
    chk = _code_mask(df, "UPE"); rec("upe_check", chk)
    df["marker"] = np.where(chk & (df.group2_ses == ".") & (df.end_group_ses == "UPE"), 1.0, np.nan)
    df["mm"] = np.where(chk, df["end_date_ses"] - df["switch_date1"], np.nan)
    df.loc[chk & (df.EP == 4) & (df.end_group_ses == "UPE"), "epg_days"] = df["mm"]
    df["upe_days2"] = 0.0
    df.loc[chk, "term_share"] = 0.0
    df.loc[chk & (df.EP == 4), "upe_days2"] = df["switch_date2"] - df["switch_date1"]
    df.loc[chk & (df.EP == 4) & (df.switch_date2.isna()), "upe_days2"] = df["end_date_ses"] - df["switch_date1"]
    df.loc[chk & (df.EP == 4) & (df.term_share == 0), "term_share"] = df["upe_days2"] / df["max_EP4_days"]
    df.loc[chk, "term_share"] = 0.8077766
    compute_group(df, chk)
    ftr(df, chk, 4)

    # ===== RDE (EP4) + UPE epg_tag hard fixes =====
    chk = _code_mask(df, "RDE"); rec("rde_check", chk)
    df["rde_days2"] = 0.0
    df.loc[chk & (df.EP == 4), "rde_days2"] = df["switch_date1"] - df["start_date_ses"]
    df.loc[chk & (df.EP == 4), "term_share"] = 2 + df["rde_days2"] / df["max_EP4_days"]
    compute_group(df, chk)
    upe_tag = (df.start_group == "UPE") & (df.EP == 4) & (df.epg_tag == 1)
    df.loc[upe_tag, "term_share"] = 0.8077766
    df.loc[upe_tag, "npd_per_epg"] = 11
    df.loc[upe_tag, "epg_perc"] = 0.0864198
    df.loc[upe_tag, "enp"] = 3.864654

    # ===== EDN == "UEN-CG" (EP4) term_share hard-coded =====
    chk = _code_mask(df, "UEN-CG"); rec("edn_check", chk)
    df["edn_days"] = 0.0
    df.loc[chk & (df.EP == 4) & (df.start_group_ses == "UEN-CG"), "edn_days"] = df["switch_date1"] - df["start_date_ses"]
    df.loc[chk & (df.EP == 4), "term_share"] = df["edn_days"] / df["max_EP4_days"]
    df.loc[chk & (df.term_share != 0.4633078), "term_share"] = 0.4633078
    compute_group(df, chk)

    # ===== I-EDN (EP4) =====
    chk = _code_mask(df, "I-EDN"); rec("iedn_check", chk)
    df["iedn_days2"] = 0.0
    df.loc[chk & (df.EP == 4) & (df.group2_ses == "I-EDN"), "iedn_days2"] = df["end_date_ses"] - df["switch_date2"]
    df.loc[chk & (df.EP == 4), "term_share"] = df["iedn_days2"] / df["max_EP4_days"]
    df.loc[(df.term_share != 0.5031906) & (df.EP == 4) & chk, "term_share"] = 0.5031906
    compute_group(df, chk)
    ftr(df, chk, 4)

    # ===== ARE (EP4) =====
    df.loc[(df.bloc_id == 433) & (df.EP == 5) & _code_mask(df, "ARE"), "bloc_id"] = 440
    chk = _code_mask(df, "ARE"); rec("are_check", chk)
    compute_group(df, chk)
    ftr(df, chk, 4)

    # ===== TDI (EP5) =====
    chk = _code_mask(df, "TDI"); rec("tdi_check", chk)
    df["tdi_days2"] = 0.0
    df.loc[chk & (df.EP == 5), "tdi_days2"] = df["switch_date2"] - df["switch_date1"]
    df.loc[chk & (df.EP == 5), "term_share"] = df["tdi_days2"] / df["max_EP5_days"]
    df.loc[chk & (df.EP == 5), "term_share"] = 0.441402
    compute_group(df, chk)

    # ===== EDD (EP5) npd epg_tag 5 =====
    chk = _code_mask(df, "EDD"); rec("edd_check", chk)
    compute_group(df, chk)
    df.loc[(df.epg_tag == 1) & chk & (df.EP == 5), "npd_per_epg"] = 5
    ftr(df, chk, 5, npds_epgtag=True)

    # ===== ITS (EP6) =====
    df.loc[(df.bloc_id == 762) & (df.EP == 6) & _code_mask(df, "ITS"), "bloc_id"] = 746
    chk = _code_mask(df, "ITS"); rec("its_check", chk)
    df["its_days2"] = 0.0
    df.loc[chk & (df.EP == 6), "its_days2"] = df["switch_date2"] - df["switch_date1"]
    df.loc[chk & (df.EP == 6), "term_share"] = df["its_days2"] / df["max_EP6_days"]
    df.loc[chk & (df.EP == 6), "term_share"] = 0.166575
    compute_group(df, chk)

    # ===== UEN (EP5/6) npd hard-coded =====
    m_uen = _code_mask(df, "UEN")
    df.loc[(df.bloc_id == 765) & (df.EP == 6) & m_uen, "bloc_id"] = 742
    df.loc[(df.bloc_id == 766) & (df.EP == 6) & m_uen, "bloc_id"] = 732
    df.loc[(df.bloc_id == 768) & (df.EP == 6) & m_uen, "bloc_id"] = 712
    chk = _code_mask(df, "UEN"); rec("uen_check", chk)
    compute_group(df, chk, set_npd=False)
    df.loc[chk & (df.EP == 5), "npd_per_epg"] = 8
    df.loc[chk & (df.EP == 6), "npd_per_epg"] = 19
    df.loc[(df.epg_tag == 1) & chk & (df.EP == 5), "npd_per_epg"] = 5

    # ===== InDem (EP5) =====
    chk = _code_mask(df, "InDem"); rec("indem_check", chk)
    compute_group(df, chk)
    df.loc[(df.epg_tag == 1) & chk & (df.EP == 5), "npd_per_epg"] = 5

    # ===== NI (no enp/concentration) =====
    chk = ((df.start_group_ses.astype("string") == "NI") &
           (df.end_group_ses.astype("string") == "NI")).fillna(False)
    rec("ni_check", chk)
    compute_group(df, chk, write_enp=False, write_conc=False, write_enp3=False, set_npct=True)

    # ===== GUE/NGL (institutionalised) =====
    df.loc[(df.bloc_id == 273) & _code_mask(df, "GUE/NGL") & (df.EP == 4), "bloc_id"] = 275
    df.loc[(df.bloc_id == 440) & _code_mask(df, "GUE/NGL") & (df.EP == 5), "bloc_id"] = 433
    df.loc[(df.bloc_id == 543) & _code_mask(df, "GUE/NGL") & (df.EP == 6), "bloc_id"] = 544
    chk = _code_mask(df, "GUE/NGL"); rec("guengl_check", chk)
    compute_group(df, chk, write_enp3=False)

    # ===== V / Greens (num 6) =====
    chk = _num_mask(df, 6); rec("v_check", chk)
    compute_group(df, chk, write_enp3=False)

    # ===== SOC (num 8) =====
    for old, new, ep in [(8, 9, 1), (154, 88, 2), (159, 91, 2), (207, 171, 3),
                         (433, 440, 5), (628, 594, 6), (755, 586, 6), (599, 600, 6)]:
        df.loc[(df.bloc_id == old) & (df.EP == ep) & _num_mask(df, 8), "bloc_id"] = new
    chk = _num_mask(df, 8); rec("soc_check", chk)
    compute_group(df, chk, write_enp3=False)
    df.loc[(df.EP == 3) & chk & (df.hoy_id == 907) & (df.epg_tag == 1), "epg_tag"] = 0

    # ===== L / Liberals (num 9) =====
    for old, new, ep in [(30, 29, 1), (113, 112, 2), (263, 221, 3), (354, 328, 4),
                         (396, 330, 4), (464, 463, 5), (754, 617, 6), (656, 657, 6)]:
        df.loc[(df.bloc_id == old) & (df.EP == ep) & _num_mask(df, 9), "bloc_id"] = new
    chk = _num_mask(df, 9); rec("l_check", chk)
    compute_group(df, chk, write_enp3=False)

    # ===== EPP (num 10) =====
    df.loc[(df.EP == 3) & _num_mask(df, 10) & (df.hoy_id == 1393) & (df.epg_tag == 1), "epg_tag"] = 0
    df.loc[(df.EP == 2) & _num_mask(df, 10) & (df.hoy_id == 1471) & (df.epg_tag == 0), "epg_tag"] = 1
    for old, new, ep in [(41, 36, 1), (28, 40, 1), (243, 242, 3), (354, 328, 4),
                         (513, 486, 5), (737, 682, 6)]:
        df.loc[(df.bloc_id == old) & (df.EP == ep) & _num_mask(df, 10), "bloc_id"] = new
    chk = _num_mask(df, 10); rec("epp_check", chk)
    compute_group(df, chk, write_enp3=False, excluded_blocs={2: [151]})

        # restore date columns to ISO strings (Stata stored numeric dates; the
    # reference CSV renders them as YYYY-MM-DD). Values are unchanged.
    for c in DATE_COLS:
        if c in df:
            dt = _EPOCH + pd.to_timedelta(df[c], unit="D")
            df[c] = dt.dt.strftime("%Y-%m-%d")

    return df
