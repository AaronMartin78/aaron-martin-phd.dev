"""Validate ported Stage A against the Stata _A dataset, column by column."""
import sys, warnings
import numpy as np, pandas as pd
warnings.simplefilter("ignore")
sys.path.insert(0, __file__.rsplit("/", 2)[0] if "/" in __file__ else ".")
from eup import config, stage_a

KEY = ["hoy_id", "EP", "start_group", "end_group"]

def load():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    ref = pd.read_csv(config.STAGE_A_REF, low_memory=False)
    return raw, ref

def main():
    raw, ref = load()
    got = stage_a.run(raw)
    # align by key (both are unique on KEY + bloc? use row order fallback)
    key = KEY if not ref.duplicated(KEY).any() and not got.duplicated(KEY).any() else KEY + ["bloc_id"]
    g = got.set_index(key).sort_index()
    r = ref.set_index(key).sort_index()
    common = g.index.intersection(r.index)
    print(f"rows got={len(got)} ref={len(ref)} aligned={len(common)}  key={key}")
    g, r = g.loc[common], r.loc[common]

    cols = ["enp", "concentration", "epg_perc", "npd_per_epg", "npd_percent",
            "epg_members", "term_share", "enp3", "bloc_id", "epg_tag",
            "ftr_epg_days", "ftr_epg_ts", "ftr_epg_perc", "ftr_npds", "ftr_concent", "ftr_enp"]
    print(f"\n{'column':16s} {'match':>7s} {'mismatch':>9s}  {'max_abs_diff':>12s}")
    print("-" * 50)
    for c in cols:
        if c not in g or c not in r:
            continue
        a, b = g[c], r[c]
        if a.dtype.kind in "fi" and b.dtype.kind in "fi":
            diff = (a.astype(float) - b.astype(float)).abs()
            rel = diff / b.astype(float).abs().replace(0, np.nan)
            close = (diff <= 1e-4) | (rel <= 1e-4) | (a.isna() & b.isna())
            mad = np.nanmax(diff.values) if len(diff) else 0
            print(f"{c:16s} {close.sum():7d} {(~close).sum():9d}  {mad:12.6g}")
        else:
            close = (a.astype("string") == b.astype("string")) | (a.isna() & b.isna())
            print(f"{c:16s} {close.sum():7d} {(~close).sum():9d}  {'(str)':>12s}")

if __name__ == "__main__":
    main()
