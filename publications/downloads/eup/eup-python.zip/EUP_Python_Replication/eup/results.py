"""Results: Table 2 (t-tests) and Table 4 (Firth penalized logit).

Ports the analysis sections of Replication_Code_12102020.do:
  * Table 2  - Welch (unequal-variance) t-tests on the 53-group dataset (_C/_D),
               comparing collapsing vs non-collapsing groups (do 2284-2354).
  * Table 4  - Firth penalized logistic regressions of switching (do 2398-2582).
"""
from __future__ import annotations
import numpy as np, pandas as pd
from scipy import stats

# --- Firth penalized logistic regression (self-contained) --------------------
# Matches Stata's `firthlogit` (incl. linear equality constraints via `constraint`).

def _firth_fit(X, y, free):
    """Newton-Raphson for Firth's penalized logit. `free` = indices of freely
    estimated coefficients; the rest are held at 0 (Stata `constraint x = 0`),
    while the Firth penalty still uses the full design matrix X."""
    import numpy as np
    n, p = X.shape
    beta = np.zeros(p)
    free = np.asarray(free)
    for _ in range(300):
        eta = X @ beta
        pr = 1.0 / (1.0 + np.exp(-eta))
        W = pr * (1 - pr)
        XtWX = X.T @ (X * W[:, None])
        Minv = np.linalg.inv(XtWX)
        Q = np.einsum("ij,jk,ik->i", X, Minv, X)
        h = W * Q
        U = X.T @ (y - pr + h * (0.5 - pr))
        step = np.linalg.solve(XtWX[np.ix_(free, free)], U[free])
        beta[free] += step
        if np.max(np.abs(step)) < 1e-10:
            break
    pll = float(np.sum(y*np.log(pr) + (1-y)*np.log(1-pr)) + 0.5*np.log(np.linalg.det(XtWX)))
    se = np.full(p, np.nan)
    se[free] = np.sqrt(np.diag(np.linalg.inv(XtWX[np.ix_(free, free)])))
    return beta, se, pll


CONTROLS = ["tenure_lag", "female", "age_lag", "govt_lag", "np_com_lag"]

# full models: (dependent var, predictors)
MODELS = {
    "all_switch_full":  ("session_switch",
        ["npd_perc_lag", "epg_perc_lag", "a1_std2", "a2_std2", "c1_std2", "c2_std2", "collapse"] + CONTROLS),
    "indiv_switch_full": ("indiv_switch_restrict1",
        ["npd_perc_lag", "epg_perc_lag", "a1_std2", "a2_std2"] + CONTROLS),
    "bloc_switch_full":  ("bloc_switch_restrict1",
        ["npd_perc_lag", "epg_perc_lag", "c1_std2", "c2_std2"] + CONTROLS),
}

# constrained "power" models: (parent full model, variables constrained to 0)
POWER = {
    "all_power":     ("all_switch_full",   ["a1_std2", "a2_std2", "c1_std2", "c2_std2", "collapse"]),
    "all_power_col": ("all_switch_full",   ["a1_std2", "a2_std2", "c1_std2", "c2_std2"]),
    "indiv_power":   ("indiv_switch_full", ["a1_std2", "a2_std2"]),
    "bloc_power":    ("bloc_switch_full",  ["c1_std2", "c2_std2"]),
}


def firth_model(b, dv, xs, zero=()):
    """Fit a Firth logit of dv on xs (listwise). Coefficients in `zero` are
    constrained to 0 but kept in the design matrix (Stata `constraint`)."""
    import numpy as np
    d = b[[dv] + xs].apply(pd.to_numeric, errors="coerce").dropna()
    cols = ["_cons"] + xs
    X = np.column_stack([np.ones(len(d)), d[xs].values])
    y = d[dv].values.astype(float)
    free = [i for i, c in enumerate(cols) if c not in zero]
    beta, se, pll = _firth_fit(X, y, free)
    coef = dict(zip(cols, beta)); bse = dict(zip(cols, se))
    return dict(n=len(d), loglik=pll, coef=coef, bse=bse)


def table4(b) -> dict:
    out = {name: firth_model(b, dv, xs) for name, (dv, xs) in MODELS.items()}
    for name, (parent, zero) in POWER.items():
        dv, xs = MODELS[parent]
        out[name] = firth_model(b, dv, xs, zero=zero)
    return out


# ----------------------------------------------------------------------------
# Table 2: Welch t-tests
# ----------------------------------------------------------------------------
def ttest(df, var, by, kind="unequal"):
    """Two-sample t-test. kind: 'pooled' (equal var), 'unequal'
    (Satterthwaite df) or 'welch' (Stata's welch df). diff = mean0 - mean1."""
    g0 = pd.to_numeric(df.loc[df[by] == 0, var], errors="coerce").dropna()
    g1 = pd.to_numeric(df.loc[df[by] == 1, var], errors="coerce").dropna()
    n0, n1 = len(g0), len(g1)
    v0, v1 = g0.var(ddof=1), g1.var(ddof=1)
    t, p = stats.ttest_ind(g0, g1, equal_var=(kind == "pooled"))
    if kind == "pooled":
        dfree = n0 + n1 - 2
    elif kind == "welch":                                    # Stata `welch`
        dfree = -2 + (v0/n0 + v1/n1)**2 / ((v0/n0)**2/(n0+1) + (v1/n1)**2/(n1+1))
    else:                                                    # Stata `unequal` (Satterthwaite)
        dfree = (v0/n0 + v1/n1)**2 / ((v0/n0)**2/(n0-1) + (v1/n1)**2/(n1-1))
    return dict(var=var, by=by, kind=kind, n0=n0, mean0=g0.mean(), n1=n1, mean1=g1.mean(),
                diff=g0.mean()-g1.mean(), t=t, df=dfree, p=p)


# backward-compatible alias
def welch_ttest(df, var, by):
    return ttest(df, var, by, kind="unequal")


def table2(c: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for by in ["collapse", "ftr", "dissolve", "merger"]:
        for var in ["term_share2", "epg_perc2", "npd_per_epg2", "enp2"]:
            rows.append(ttest(c, var, by, kind="unequal"))
    return pd.DataFrame(rows)



# ----------------------------------------------------------------------------
# Appendix B: McElroy replication (plain logit + Firth logit)
# ----------------------------------------------------------------------------
APPB_BASE = ["mep_tenure", "a1_std", "major", "key_committee", "com_leader",
             "kc_cl", "EPG_leader"]  # kc_cl = key_committee # com_leader interaction


def appendix_b(mc: pd.DataFrame) -> dict:
    """McElroy models (do 2599-2610).

    The plain logit drops the observations that ed_dummy predicts perfectly and
    omits ed_dummy (Stata's behaviour); the Firth logit keeps them all.
    """
    import numpy as np
    mc = mc.copy()
    mc["kc_cl"] = mc["key_committee"] * mc["com_leader"]

    # Firth logit, full sample incl. ed_dummy
    xs = APPB_BASE + ["ed_dummy"]
    d = mc[["session_switch"] + xs].apply(pd.to_numeric, errors="coerce").dropna()
    X = np.column_stack([np.ones(len(d)), d[xs].values])
    y = d["session_switch"].values.astype(float)
    beta, se, pll = _firth_fit(X, y, np.arange(X.shape[1]))
    cols = ["_cons"] + xs
    firth = dict(n=len(d), loglik=pll, coef=dict(zip(cols, beta)), bse=dict(zip(cols, se)))

    # plain logit on ed_dummy==0 subset (ed_dummy omitted, obs perfectly
    # predicted by it dropped), matching Stata
    import statsmodels.api as sm
    d2 = mc[mc.ed_dummy == 0][["session_switch"] + APPB_BASE].apply(pd.to_numeric, errors="coerce").dropna()
    res = sm.Logit(d2["session_switch"], sm.add_constant(d2[APPB_BASE])).fit(disp=0)
    coef = {("_cons" if k == "const" else k): v for k, v in res.params.items()}
    logit = dict(n=int(res.nobs), loglik=float(res.llf), coef=coef,
                 bse={("_cons" if k == "const" else k): v for k, v in res.bse.items()})
    return {"mc_logit": logit, "mc_firth": firth}
