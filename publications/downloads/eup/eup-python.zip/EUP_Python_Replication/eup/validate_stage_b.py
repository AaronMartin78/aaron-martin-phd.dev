"""Validate ported Stage B against the Stata _B dataset."""
import warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
from eup import config, stage_a, stage_b

KEY = ["hoy_id", "EP", "start_group", "end_group", "bloc_id"]

def main():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    ref = pd.read_csv(config.STAGE_B_REF, low_memory=False)
    got = stage_b.run(stage_a.run(raw))
    key = KEY if not (ref.duplicated(KEY).any() or got.duplicated(KEY).any()) else KEY + ["start_date_ses"]
    g = got.set_index(key).sort_index(); r = ref.set_index(key).sort_index()
    ix = g.index.intersection(r.index); g, r = g.loc[ix], r.loc[ix]
    print(f"rows got={len(got)} ref={len(ref)} aligned={len(ix)} key={key}")
    focus = ["epg_median_d1","epg_median_d2","npd_median_d1","npd_median_d2",
             "a1_raw","a2_raw","c1_raw","c2_raw","a1_lagged","a2_lagged","c1_lagged","c2_lagged",
             "a1_std2","a2_std2","c1_std2","c2_std2","epg_perc_lag","npd_perc_lag",
             "age_lag","tenure_lag","govt_lag","np_com_lag","start_ses_switch","late_start","age_martin"]
    allcols = [c for c in r.columns if c in g.columns]
    print(f"\ncomparing {len(allcols)} shared columns\n")
    bad = []
    for c in allcols:
        a, b = g[c], r[c]
        if a.dtype.kind in "fi" and b.dtype.kind in "fi":
            diff = (a.astype(float) - b.astype(float)).abs()
            rel = diff / b.astype(float).abs().replace(0, np.nan)
            n = int((~((diff <= 1e-3) | (rel <= 1e-4) | (a.isna() & b.isna()))).sum())
        else:
            n = int((~((a.astype("string") == b.astype("string")) | (a.isna() & b.isna()))).sum())
        if n: bad.append((c, n))
    print("FOCUS columns:")
    for c in focus:
        n = dict(bad).get(c, 0)
        print(f"  {c:18s} {'OK' if n==0 else str(n)+' mismatch'}")
    print(f"\nALL columns with mismatches ({len(bad)}):")
    for c, n in sorted(bad, key=lambda x: -x[1]):
        print(f"  {c:22s} {n}")

if __name__ == "__main__":
    main()
