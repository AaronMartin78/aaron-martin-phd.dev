"""Validate every published number in Tables 2 & 4 and Appendix B against
replication_log.log: all 23 t-tests, 7 Firth models, and 2 McElroy models."""
import re, warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
from eup import config, stage_a, stage_b, stage_c, results


def parse_ttests(logpath):
    txt = open(logpath, encoding="latin-1").read().replace("\r", "").splitlines()
    out = []
    for i, l in enumerate(txt):
        m = re.search(r"ttest (\w+), by\((\w+)\)(.*)", l)
        if not m:
            continue
        var, grp, opt = m.group(1), m.group(2), m.group(3).strip()
        means, t, dfree = {}, None, None
        for ln in txt[i:i+24]:
            mm = re.match(r"\s*([01])\s*\|\s*(\d+)\s+(-?[\d.]+)", ln)
            if mm: means[mm.group(1)] = (int(mm.group(2)), float(mm.group(3)))
            mt = re.search(r"\bt =\s*(-?[\d.]+)", ln)
            if mt: t = float(mt.group(1))
            md = re.search(r"degrees of freedom =\s*(-?[\d.]+)", ln)
            if md: dfree = float(md.group(1))
        if "0" in means and "1" in means and t is not None:
            kind = "welch" if opt == "welch" else ("unequal" if "unequal" in opt else "pooled")
            out.append((var, grp, kind, means["0"], means["1"], t, dfree))
    return out


# model ground truth (N, penalized/plain logLik) from replication_log.log
MODEL_TRUTH = {
    "all_switch_full": (3962, -637.68894), "indiv_switch_full": (3962, -455.84114),
    "bloc_switch_full": (3962, -326.97514), "all_power": (3962, -1288.8106),
    "all_power_col": (3962, -697.40471), "indiv_power": (3962, -477.35726),
    "bloc_power": (3962, -361.04744),
}
APPB_TRUTH = {"mc_logit": (545, -203.50908), "mc_firth": (579, -193.07426)}


def main():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    B = stage_b.run(stage_a.run(raw)); C = stage_c.run(B)
    lines, npass, nfail = ["# Results validation vs replication_log.log", ""], 0, 0

    # --- Table 2 ---
    lines.append("## Table 2 - t-tests (23 tests)")
    for var, grp, kind, (n0, m0), (n1, m1), t, dfree in parse_ttests(config.LOG_FILE):
        r = results.ttest(C, var, grp, kind=kind)
        ok = (r["n0"] == n0 and r["n1"] == n1 and abs(r["mean0"]-m0) < 5e-4
              and abs(r["mean1"]-m1) < 5e-4 and abs(r["t"]-t) < 5e-4
              and (dfree is None or abs(r["df"]-dfree) < 5e-3))
        npass += ok; nfail += (not ok)
        if not ok:
            lines.append(f"  FAIL {var} by {grp} ({kind}): t {r['t']:.4f} vs {t}")
    lines.append(f"  -> {npass} passed, {nfail} failed")

    # --- Table 4 ---
    lines.append("\n## Table 4 - Firth models (7)")
    t4 = results.table4(B)
    for name, (N, LL) in MODEL_TRUTH.items():
        m = t4[name]; ok = (m["n"] == N and abs(m["loglik"]-LL) < 1e-2)
        npass += ok; nfail += (not ok)
        lines.append(f"  {'OK ' if ok else 'FAIL'} {name:16s} N={m['n']} (stata {N})  logLik*={m['loglik']:.5f} (stata {LL})")

    # --- Appendix B ---
    lines.append("\n## Appendix B - McElroy (2 models)")
    ab = results.appendix_b(pd.read_csv(config.CONVERTED / "McElroy_replication_data.csv", low_memory=False))
    for name, (N, LL) in APPB_TRUTH.items():
        m = ab[name]; ok = (m["n"] == N and abs(m["loglik"]-LL) < 1e-2)
        npass += ok; nfail += (not ok)
        lines.append(f"  {'OK ' if ok else 'FAIL'} {name:10s} N={m['n']} (stata {N})  logLik={m['loglik']:.5f} (stata {LL})")

    lines.append(f"\n## TOTAL: {npass} passed, {nfail} failed")
    report = "\n".join(lines)
    (config.OUT / "results_validation.md").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
