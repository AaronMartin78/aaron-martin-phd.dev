"""Stage C/D: _B -> _C (group-level dataset for the Table 2 t-tests).

Ports lines 2107-2272 of Replication_Code_12102020.do. One row per party group
(epg_tag==1), with failed-to-reform-adjusted variables (the *2 versions), plus
six groups appended by hand (they had no tagged row) and a battery of
ftr/collapse/dissolve/merger corrections. _D is identical data (the t-tests in
lines 2284-2357 do not modify it), so run() serves for both.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

KEEP = ["EP", "start_group", "start_group_num", "collapse", "ftr", "merger", "dissolve",
        "term_share", "term_share2", "epg_perc", "epg_perc2", "npd_per_epg", "npd_per_epg2",
        "enp", "enp2", "concentration", "concent2"]

# six groups appended via `set obs`; only the listed fields are set (others NaN)
ADDED = [
    dict(EP=2, start_group="TCDI",  merger=0, dissolve=1, ftr=0, collapse=1,
         term_share2=0.033954,  epg_perc2=0.016,     npd_per_epg2=6,  concent2=1837, start_group_num=30, enp2=4.545454),
    dict(EP=4, start_group="FE",    merger=1, dissolve=0, ftr=0, collapse=1,
         term_share2=0.192234,  epg_perc2=0.038,     npd_per_epg2=2,  concent2=9311, start_group_num=31, enp2=1.073973),
    dict(EP=4, start_group="EDN",   merger=0, dissolve=1, ftr=0, collapse=1,
         term_share2=0.4633078, epg_perc2=0.026,     npd_per_epg2=6,  concent2=3241, start_group_num=32, enp2=3.08547),
    dict(EP=4, start_group="I-EDN", merger=0, dissolve=0, ftr=1, collapse=1,
         term_share2=0.5031906, epg_perc2=0.030,     npd_per_epg2=10, concent2=2107, start_group_num=33, enp2=4.745098),
    dict(EP=6, start_group="ITS",   merger=0, dissolve=1, ftr=0, collapse=1,
         term_share2=0.166575,  epg_perc2=0.019,     npd_per_epg2=10, concent2=1235, start_group_num=34, enp2=7.714286),
    dict(EP=3, start_group="ED",    merger=1, dissolve=0, ftr=0, collapse=1,
         term_share2=2.5558,    epg_perc2=0.0561983, npd_per_epg2=2,  concent2=5575, start_group_num=11, enp2=1.124514),
]


def run(b: pd.DataFrame) -> pd.DataFrame:
    df = b.copy()

    # ftr-adjusted variables (do 2113-2131)
    df["term_share2"]  = df["term_share"];   df.loc[df.ftr == 1, "term_share2"]  = df["ftr_epg_ts"]
    df["epg_perc2"]    = df["epg_perc"];      df.loc[df.ftr == 1, "epg_perc2"]    = df["ftr_epg_perc"]
    df["npd_per_epg2"] = df["npd_per_epg"];   df.loc[df.ftr == 1, "npd_per_epg2"] = df["ftr_npds"]
    df["enp2"]         = df["enp"];           df.loc[df.ftr == 1, "enp2"]         = df["ftr_enp"]
    df["concent2"]     = df["concentration"]; df.loc[df.ftr == 1, "concent2"]     = df["ftr_concent"]

    # one row per group
    g = df[df.epg_tag == 1][KEEP].copy()

    # ftr corrections on existing rows (do 2143-2254, existing-group parts)
    def setftr(cond, col="ftr", val=1):
        g.loc[cond, col] = val
    setftr((g.EP == 1) & (g.start_group == "CDI"))
    setftr((g.EP == 1) & (g.start_group == "DEP"))
    setftr((g.EP == 2) & (g.start_group == "COM"))
    setftr((g.EP == 3) & (g.start_group == "CG"))
    setftr((g.EP == 3) & (g.start_group == "DR"))
    setftr((g.EP == 3) & (g.start_group == "RBW"))
    # RDE hard-coded values (do 2179-2182)
    rde = (g.EP == 4) & (g.start_group == "RDE")
    g.loc[rde, "term_share2"] = 2.192234
    g.loc[rde, "npd_per_epg2"] = 5
    g.loc[rde, "concent2"] = 3673
    g.loc[rde, "enp2"] = 2.7222
    setftr((g.EP == 4) & (g.start_group == "ARE"))
    setftr(g.start_group == "EDD")
    g.loc[(g.start_group == "NI") & (g.EP == 2), "dissolve"] = 0
    g.loc[(g.start_group == "NI") & (g.EP == 2), "collapse"] = 0
    g.loc[(g.start_group == "UPE") & (g.EP == 4), "merger"] = 0
    setftr((g.start_group == "UPE") & (g.EP == 4))
    g.loc[(g.start_group == "NI") & (g.EP == 6), "dissolve"] = 0
    g.loc[(g.start_group == "NI") & (g.EP == 6), "collapse"] = 0
    setftr((g.start_group == "UEN") & (g.EP == 6))
    setftr((g.start_group == "InDem") & (g.EP == 6))
    setftr((g.start_group == "UEN") & (g.EP == 5), val=0)
    g.loc[(g.start_group == "UEN") & (g.EP == 5), "collapse"] = 0
    setftr((g.start_group == "GUE") & (g.EP == 3), val=0)

    # append the six hand-built groups
    g = pd.concat([g, pd.DataFrame(ADDED)], ignore_index=True)

    # collapse rollup (do 2256-2258) and drop NI (2260)
    g.loc[g.ftr == 1, "collapse"] = 1
    g.loc[g.dissolve == 1, "collapse"] = 1
    g.loc[g.merger == 1, "collapse"] = 1
    g = g[g.start_group != "NI"].reset_index(drop=True)

    return g[KEEP]
