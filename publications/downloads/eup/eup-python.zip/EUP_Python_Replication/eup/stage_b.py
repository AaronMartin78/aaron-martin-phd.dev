"""Stage B: _A -> _B (analysis dataset).

Ports lines 1943-2098 of Replication_Code_12102020.do: DW-Nominate group/
delegation medians, MEP-to-group and delegation-to-group distances, and their
lagged (previous-session) and standardised versions.

Two verbatim copy-paste bugs in the original are preserved so results match:
  * c2_lagged is seeded from lag_ref_c1 (not c2)   [do line 2002]
  * np_com_lag is seeded from lag_ref_govt (not com) [do line 2070]
"""
from __future__ import annotations
import numpy as np
import pandas as pd

_EPOCH = pd.Timestamp("1960-01-01")


def _std(s: pd.Series) -> pd.Series:
    """egen std: (x - mean) / sample sd (ddof=1), ignoring missing."""
    return (s - s.mean()) / s.std(ddof=1)


def _lagged(df, raw, out, ref, sss, ftr):
    """Replicate the gen/replace lag pattern used throughout Stage B."""
    df[ref] = df.groupby("hoy_id")[raw].shift(1)
    df[out] = 0.0
    df.loc[(sss == 1) & (ftr == 0), out] = df[ref]
    df.loc[(sss == 1) & (ftr == 1), out] = df[raw]
    df.loc[(sss == 0), out] = df[raw]
    df.loc[df[out].isna(), out] = df[raw]


def run(a: pd.DataFrame) -> pd.DataFrame:
    df = a.copy()
    # load order of _A (do line 1930): sort hoy_id EP start_group end_group bloc_id
    df = df.sort_values(["hoy_id", "EP", "start_group", "end_group", "bloc_id"],
                        kind="stable").reset_index(drop=True)

    # --- hand corrections (do 1947-1954) ---
    same_day = df["switch_date1"].astype("string") == df["start_date_ses"].astype("string")
    m = same_day & (df.late_start == 1) & (df.collapse == 1) & (df.start_ses_switch == 1)
    df.loc[m, "start_ses_switch"] = 0
    df.loc[(df.start_ses_switch == 0) & (df.ftr == 1), "start_ses_switch"] = 1
    df.loc[(df.hoy_id == 23745) & (df.EP == 6), "late_start"] = 0
    for hid in (23747, 24088, 24089, 23745):
        df.loc[(df.hoy_id == hid) & (df.EP == 6), "start_ses_switch"] = 0

    # --- DW-Nominate medians ---
    df["epg_median_d1"] = df.groupby(["EP", "start_group_num"])["dw_nomd1"].transform("median")
    df["epg_median_d2"] = df.groupby(["EP", "start_group_num"])["dw_nomd2"].transform("median")
    df["npd_median_d1"] = df.groupby(["EP", "bloc_id"], dropna=False)["dw_nomd1"].transform("median")
    df["npd_median_d2"] = df.groupby(["EP", "bloc_id"], dropna=False)["dw_nomd2"].transform("median")

    # --- distances ---
    df["a1_raw"] = (df["dw_nomd1"] - df["epg_median_d1"]).abs()
    df["a2_raw"] = (df["dw_nomd2"] - df["epg_median_d2"]).abs()
    df["c1_raw"] = (df["npd_median_d1"] - df["epg_median_d1"]).abs()
    df["c2_raw"] = (df["npd_median_d2"] - df["epg_median_d2"]).abs()

    # lags are computed after `sort hoy_id EP`
    df = df.sort_values(["hoy_id", "EP"], kind="stable").reset_index(drop=True)
    sss, ftr = df["start_ses_switch"], df["ftr"]

    _lagged(df, "a1_raw", "a1_lagged", "lag_ref_a1", sss, ftr)
    _lagged(df, "a2_raw", "a2_lagged", "lag_ref_a2", sss, ftr)
    _lagged(df, "c1_raw", "c1_lagged", "lag_ref_c1", sss, ftr)
    # c2_lagged: original seeds from lag_ref_c1 (bug, preserved)
    df["lag_ref_c2"] = df.groupby("hoy_id")["c2_raw"].shift(1)
    df["c2_lagged"] = 0.0
    df.loc[(sss == 1) & (ftr == 0), "c2_lagged"] = df["lag_ref_c1"]
    df.loc[(sss == 1) & (ftr == 1), "c2_lagged"] = df["c2_raw"]
    df.loc[(sss == 0), "c2_lagged"] = df["c2_raw"]
    df.loc[df["c2_lagged"].isna(), "c2_lagged"] = df["c2_raw"]

    df["a1_std2"] = _std(df["a1_lagged"])
    df["a2_std2"] = _std(df["a2_lagged"])
    df["c1_std2"] = _std(df["c1_lagged"])
    df["c2_std2"] = _std(df["c2_lagged"])

    _lagged(df, "epg_perc", "epg_perc_lag", "lag_ref_epgperc", sss, ftr)
    _lagged(df, "npd_percent", "npd_perc_lag", "lag_ref_npdperc", sss, ftr)

    # age corrections (do 2032-2036)
    for hid, ep, val in [(4553, 5, 51.50), (4323, 5, 51.42), (4519, 5, 34.08),
                         (4519, 6, 39.08), (28217, 6, 49.00)]:
        df.loc[(df.hoy_id == hid) & (df.EP == ep), "age_martin"] = val

    _lagged(df, "age_martin", "age_lag", "lag_ref_age", sss, ftr)
    _lagged(df, "mep_tenure", "tenure_lag", "lag_ref_tenure", sss, ftr)
    _lagged(df, "govt2", "govt_lag", "lag_ref_govt", sss, ftr)

    # np_com_lag: original seeds from lag_ref_govt (bug, preserved)
    df["lag_ref_com"] = df.groupby("hoy_id")["np_com"].shift(1)
    df["np_com_lag"] = 0.0
    df.loc[(sss == 1) & (ftr == 0), "np_com_lag"] = df["lag_ref_govt"]
    df.loc[(sss == 1) & (ftr == 1), "np_com_lag"] = df["np_com"]
    df.loc[(sss == 0), "np_com_lag"] = df["np_com"]
    df.loc[df["np_com_lag"].isna(), "np_com_lag"] = df["np_com"]

    return df
