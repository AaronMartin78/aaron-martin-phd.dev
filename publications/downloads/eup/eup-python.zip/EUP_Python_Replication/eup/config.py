import os
from pathlib import Path
DATA = Path(os.environ.get("EUP_DATA_ROOT", Path(__file__).resolve().parents[2]))
CONVERTED = DATA / "Converted Data Files"
RAW_INPUT   = CONVERTED / "EUP_replication_dataset_12092020_2.csv"
STAGE_A_REF = CONVERTED / "EUP_replication_dataset_12092020_A_2.csv"
STAGE_B_REF = CONVERTED / "EUP_replication_dataset_12092020_B_3.csv"
STAGE_C_REF = CONVERTED / "EUP_replication_dataset_12092020_C_2.csv"
STAGE_D_REF = CONVERTED / "EUP_replication_dataset_12092020_D_2.csv"
LOG_FILE = DATA / "reference" / "replication_log.log"
OUT = Path(__file__).resolve().parents[1] / "output"; OUT.mkdir(parents=True, exist_ok=True)
