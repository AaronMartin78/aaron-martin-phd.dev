> The Python port covers the data construction and selected statistical tables from the December 2020 replication files. Its saved reports do not establish complete reproduction of every published figure, table or appendix. See the included README and saved validation reports for scope and tolerances.

# EUP Paper - Python Replication

A pure-Python port of the Stata replication pipeline for the European Union
Politics paper on strategic switching and weak institutionalization
(`Replication_Code_12102020.do`). It runs end-to-end from the raw replication
dataset with **no Stata licence required**. The data pipeline and the paper's
main result tables are validated against the original Stata datasets and log.
Some components are not reproduced - see "Gaps" below.

## Validation summary

| Component | Check | Result |
|-----------|-------|--------|
| Stage A (do 46-1932)   | 241 columns x 3977 rows vs `_A` | 100% |
| Stage B (do 1943-2098) | 272 columns x 3977 rows vs `_B` | 100% |
| Stage C/D (do 2107-2357) | 17 columns x 53 rows vs `_C` | 100% |
| Table 2 t-tests | 23 tests vs log (means, t, df) | 23/23 |
| Table 4 Firth models | 3 full + 4 constrained, coefs & logLik vs log | 7/7 |
| Appendix B (McElroy) | plain logit + Firth vs log | 2/2 |

Coefficients match to ~5 decimal places; log-likelihoods to the digit.

## Layout

```
eup/
  config.py            paths (set EUP_DATA_ROOT to point at the data folder)
  stage_a.py           raw  -> Stage A   (group-level variables, 26 EP groups)
  stage_b.py           A    -> Stage B   (distances, lags, standardized vars)
  stage_c.py           B    -> Stage C   (53-group t-test dataset; == D)
  results.py           Table 2 t-tests, Table 4 Firth models, Appendix B
                       (self-contained Firth logit, incl. constrained fits)
  validate_stage_a.py  column-by-column check vs _A
  validate_stage_b.py  column-by-column check vs _B
  validate_results.py  all t-tests + models vs replication_log.log
run_all.py             runs the whole pipeline; writes output/ + validation_report.md
output/                stage_A/B/C.csv, table2_ttests.csv, table4_firthlogit.csv,
                       appendixB_mcelroy.csv, validation_report.md, results_validation.md
```

## Run it

```bash
pip install pandas numpy scipy statsmodels
python run_all.py             # data pipeline + tables + data-stage validation
python -m eup.validate_results  # checks every number in Tables 2/4 & App. B vs the log
```

Input is the converted CSV `EUP_replication_dataset_12092020_2.csv` (from the
official Replication Files folder) in `../Converted Data Files/`.

## Notes / fidelity

- The Firth penalized logit is implemented directly (Newton-Raphson on the
  penalized score). It reproduces Stata `firthlogit` exactly, including the
  `constraint(...)` behaviour used by the "power" models, where constrained
  coefficients are fixed at 0 but the penalty still uses the full design matrix.
- Two verbatim copy-paste bugs in the original do-file (`c2_lagged` seeded from
  `lag_ref_c1`; `np_com_lag` from `lag_ref_govt`) are **preserved** so results
  match. Fixing them is a one-line change in `stage_b.py` if desired.
- The McElroy plain logit drops the 34 observations that `ed_dummy` predicts
  perfectly and omits `ed_dummy` (Stata's behaviour); the Firth version keeps
  all 579. Both reproduce exactly.
- Stata stores numbers as 32-bit float; residual data-stage differences are at
  that precision (~1e-6 relative) and are pure rounding, not logic.

## Gaps / not reproduced (for future work)

What **is** validated: the full data pipeline (Stages A-D), Table 2 (all 23
t-tests, which also cover Appendix C), Table 4 (all 7 Firth models), and
Appendix B (McElroy). Coefficients match to ~5 decimals, log-likelihoods to the
digit, data cells to 32-bit-float precision.

What is **not** yet done, and would need to be added for a 100%-complete
replication:

- **Figure 2** (DW-Nominate scatter, do ~2363-2395). A plot of the already-computed
  `dw_nomd1`/`dw_nomd2` group medians; no estimation, just plotting.
- **Appendix D - Robustness Checks and Coding Decisions** (do ~2610 onward). These
  additional models/checks were not ported or validated at all.
- **Table 3** (do ~2083-2094). This is descriptive cross-tabulation (`tab2`) of the
  dependent variables by EP; the underlying variables are all present in Stage B,
  but the tabulations themselves are not separately generated.
- **Standard errors** for Table 2 / Table 4 are computed but only spot-checked; the
  formal validation above is on point estimates, degrees of freedom, and
  log-likelihoods.

None of these gaps affect the validated results; they are additional outputs that
were out of scope for this pass.
