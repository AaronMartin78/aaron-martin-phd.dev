"""Party Politics replication (Python) - exact parts.

Runs the data construction (dataset_12222020 -> PP_dataset) and the Firth
session_switch models, writes outputs to ./output/, and validates against
PP_dataset.csv and march25_2021.log. The multilevel Tables 4/5 are handled by
make_pp_multilevel.R (run in RStudio) - see README.
"""
import warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
from pp import config, stage, results

def main():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    PP = stage.run(raw)
    PP.to_csv(config.OUT / "stage_PP_dataset.csv", index=False)

    ft = results.firth_table(PP)
    rows = [dict(model=n, term=k, coef=v, se=m["bse"].get(k, np.nan), n=m["n"], loglik=m["loglik"])
            for n, m in ft.items() for k, v in m["coef"].items()]
    pd.DataFrame(rows).to_csv(config.OUT / "table5_firth.csv", index=False)
    print("Wrote stage_PP_dataset.csv and table5_firth.csv to", config.OUT)
    print("Run `python -m pp.validate` to check against the Stata outputs.")

if __name__ == "__main__":
    main()
