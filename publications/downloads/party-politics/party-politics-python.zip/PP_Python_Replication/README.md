> IMPORTANT VERSION NOTE: this is the archived March 25, 2021 analysis and its later Python port. The final published article (2022 online; 2023 journal issue) reports Firth penalized logistic regression in Table 4. The archived README refers to earlier multilevel Tables 4/5; those descriptions must not be read as a verified replication of the final published paper. The saved checks cover data construction and three archived Firth models. No full final-publication replication is claimed.

# Party Politics Paper - Python Replication

Python port of the ambitious-switching / multi-switching paper's Stata pipeline
(`PP_20210325.do`). What can be reproduced exactly in Python is; the multilevel
core is provided as R scripts for local RStudio.

## Validation summary

| Component | Method | Result |
|-----------|--------|--------|
| Data construction (`dataset_12222020` -> `PP_dataset`, do 8-176) | 558 cols x 3977 rows vs `PP_dataset.csv` | **100%** |
| Firth `session_switch` models (Table 5 robustness, do 716-796) | logLik & coefs vs `march25_2021.log` | **3/3 exact** |
| Multilevel Tables 4 & 5 (`xtmelogit`) | R/lme4 scripts for local RStudio | not validated here (see below) |

## The multilevel models (Tables 4 & 5) - status and correction

Tables 4 and 5 are Stata `xtmelogit` models. On investigation they are
**three-level NESTED** models, not two-level:

    xtmelogit <dv> <x> || start_group_num: || bloc_id3:

- random intercept for the EP party group (`start_group_num`) **and** for the
national-party delegation (`bloc_id3`) nested within it. In lme4:
`(1 | start_group_num/bloc_id3)`. (An earlier version of the R script used only
`(1 | start_group_num)` - the wrong structure, which attenuates the coefficients.)

Reproduction status:
- The **exact Stata coefficients are preserved in `march25_2021.log`** and are
  recoverable at full precision. For example the Table 5 intensity column
  (logLik -563.988; z_intense2 -0.3592, c_epg_perc -9.314, _cons -5.6818) and the
  quadratic column (logLik -513.389; a1_std2 1.3359) match the published table.
- **Independent reproduction in Python did not succeed here.** A two-level fit is
  systematically ~20-40% attenuated (wrong structure); the correct three-level
  nested fit could not be optimized within the sandbox compute limit, and Stata
  itself hit "not concave" iterations, so the models are numerically delicate.
- `make_pp_multilevel.R` (corrected to the nested structure, with the log
  ground-truth values embedded) is the recommended path - run it in your RStudio
  and compare. `lme4` will be close but not guaranteed identical to `xtmelogit`.

See `output/multilevel_findings.md` for the full ground-truth table.

## Layout

```
pp/
  config.py     paths (set PP_DATA_ROOT to the data folder)
  stage.py      dataset_12222020 -> PP_dataset
  results.py    Firth session_switch models + plain-logit helper
  validate.py   checks pipeline (all cols) + Firth models vs the log
run_all.py            runs pipeline + Firth; writes output/
make_pp_multilevel.R  lme4 scripts for Tables 4/5 (run in RStudio)
output/               stage_PP_dataset.csv, table5_firth.csv, validation_report.md
```

## Run it

```bash
pip install pandas numpy scipy statsmodels
python run_all.py
python -m pp.validate
# then, in RStudio:  source("make_pp_multilevel.R")
```
