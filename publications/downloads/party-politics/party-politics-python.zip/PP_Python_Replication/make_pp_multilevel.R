# ============================================================================
# Party Politics - multilevel models (Tables 4 & 5) in R, for local RStudio.
#
# IMPORTANT (corrected): the published tables use THREE-LEVEL NESTED models,
#   Stata:  xtmelogit <dv> <x> || start_group_num: || bloc_id3:
#   i.e. a random intercept for the EP party group (start_group_num) AND a
#   random intercept for the national-party delegation (bloc_id3) nested within
#   it. lme4 equivalent:  (1 | start_group_num/bloc_id3).
# (An earlier version of this script used only (1 | start_group_num) - that is
#  the wrong structure and produces attenuated coefficients.)
#
# These could not be fit in the Python sandbox (nested quadrature is too heavy,
# and Stata itself reported "not concave" iterations). glmer with adaptive
# Gauss-Hermite quadrature is the closest practical match; it may still differ
# from Stata's xtmelogit. Ground-truth values from march25_2021.log are shown
# next to each model for comparison.
#
# Usage in RStudio:
#   install.packages("lme4")
#   setwd(".../PP_Python_Replication"); source("make_pp_multilevel.R")
# ============================================================================
library(lme4)

path <- "output/stage_PP_dataset.csv"
if (!file.exists(path)) path <- "../Converted Data Files/PP_dataset.csv"
d <- read.csv(path)
for (v in c("female","govt2","collapse","ftr","dissolve","merger",
            "start_group_num","bloc_id3")) d[[v]] <- factor(d[[v]])

ctrl <- glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 3e5))
# nAGQ must be 1 (Laplace) for models with >1 random-effect term in lme4;
# for a single grouping factor you may raise nAGQ (e.g. 7) to mimic Stata.
fit3 <- function(f) glmer(f, data = d, family = binomial, nAGQ = 1, control = ctrl)

RE <- "(1 | start_group_num/bloc_id3)"

cat("\n===== TABLE 5: amb_switch, 3-level nested =====\n")
# --- intensity  (Stata log line 141: LL = -563.988; z_intense2 -0.3592,
#     c_npd_perc -11.160, c_epg_perc -9.314, govt2 -0.7115, mep_tenure 0.3726,
#     age 0.00553, female -0.7780, _cons -5.6818) ---
m_int <- fit3(as.formula(paste("amb_switch ~ z_intense2 + c_npd_perc + c_epg_perc +",
             "govt2 + mep_tenure + age_martin + female +", RE)))

# --- quadratic (Stata log line 372: LL = -513.389; a1_std2 1.3359, a2_std2 0.6217,
#     a1^2 -0.1782, a2^2 -0.0933, c_npd_perc -12.744, ...) ---
m_quad <- fit3(as.formula(paste("amb_switch ~ a1_std2 + a2_std2 + I(a1_std2^2) +",
             "I(a2_std2^2) + c_npd_perc + c_epg_perc + govt2 + mep_tenure +",
             "age_martin + female +", RE)))

# --- full / interaction (Stata log line 722: LL = -493.246; a1_std2 1.6026,
#     a2_std2 0.8869, a1^2 -0.2034, a2^2 -0.1150) ---
m_full <- fit3(as.formula(paste("amb_switch ~ a1_std2 * a2_std2 + I(a1_std2^2) +",
             "I(a2_std2^2) + c_npd_perc + c_epg_perc + govt2 + mep_tenure +",
             "age_martin + female +", RE)))

for (nm in c("m_int","m_quad","m_full")) {
  cat("\n---", nm, "--- logLik =", round(logLik(get(nm)), 3), "\n")
  print(round(summary(get(nm))$coefficients, 4))
}

cat("\n===== TABLE 4: multiswitch, same nested structure =====\n")
m_ms_con <- fit3(as.formula(paste("multiswitch ~ c_npd_perc + c_epg_perc + govt2 +",
              "mep_tenure + age_martin + female +", RE)))
m_ms_col <- fit3(as.formula(paste("multiswitch ~ collapse + c_npd_perc + c_epg_perc +",
              "govt2 + mep_tenure + age_martin + female +", RE)))
m_ms_dis <- fit3(as.formula(paste("multiswitch ~ ftr + dissolve + merger + c_npd_perc +",
              "c_epg_perc + govt2 + mep_tenure + age_martin + female +", RE)))
for (nm in c("m_ms_con","m_ms_col","m_ms_dis")) {
  cat("\n---", nm, "--- logLik =", round(logLik(get(nm)), 3), "\n")
  print(round(summary(get(nm))$coefficients, 4))
}
