"""Party Politics data construction: dataset_12222020 -> PP_dataset.

Ports lines 8-176 of PP_20210325.do: c_epg_perc outlier corrections, centred
NPD share, the ambitious-switch dependent variables, career switch totals,
intensity, and the delegation id (bloc_id3) used for the multilevel models.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def _cap(df, group, ep, thr, side):
    """Stata: egen m = max/min(c_epg_perc) if group&EP; replace c_epg_perc = m
    if group&EP & (c_epg_perc < thr [max] / > thr [min])."""
    sub = (df.start_group == group) & (df.EP == ep)
    if side == "max":
        m = df.loc[sub, "c_epg_perc"].max()
        df.loc[sub & (df.c_epg_perc < thr), "c_epg_perc"] = m
    else:
        m = df.loc[sub, "c_epg_perc"].min()
        df.loc[sub & (df.c_epg_perc > thr), "c_epg_perc"] = m


def run(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()

    # --- c_epg_perc corrections (do 15-67) ---
    df.loc[(df.start_group == "RDE") & (df.EP == 2) & (df.c_epg_perc < 0.20), "c_epg_perc"] = -0.1457988
    _cap(df, "EPP", 3, 0, "max")
    _cap(df, "GUE", 3, 0, "min")
    _cap(df, "LDR", 3, -0.11276, "max")
    _cap(df, "ARE", 4, -0.17, "max")
    _cap(df, "ELDR", 4, -0.128, "max")
    _cap(df, "EPP", 4, 0, "max")
    _cap(df, "GUE/NGL", 4, -0.1590, "max")
    _cap(df, "UPE", 4, -0.207, "min")
    _cap(df, "EPP-ED", 5, 0, "max")
    _cap(df, "PES", 5, 0, "max")
    _cap(df, "ALDE", 6, -0.07, "max")

    # --- centred NPD share (do 70-71) ---
    df["c_npd_perc"] = df["npd_percent"] - df["npd_percent"].mean()

    # --- dissertation-article corrections (do 76-80) ---
    df.loc[(df.start_group == "CDI") & (df.EP > 1), "ftr"] = 1
    for col in ["dissolve", "inst_switch", "casc_cat", "casc_cat2"]:
        df.loc[(df.hoy_id == 1289) & (df.EP == 3), col] = 0

    # --- dependent variables (do 83-96) ---
    df = df.drop(columns=["amb_switch"])
    df["amb_switch"] = 0
    df.loc[(df.indiv_switch_restrict1 == 1) & (df.switch_count_ses == 1), "amb_switch"] = 1
    df.loc[(df.bloc_switch_restrict1 == 1) & (df.switch_count_ses == 1), "amb_switch"] = 1
    df["amb_switch_indiv"] = 0
    df.loc[(df.indiv_switch_restrict1 == 1) & (df.switch_count_ses == 1), "amb_switch_indiv"] = 1
    df["amb_switch_bloc"] = 0
    df.loc[(df.bloc_switch_restrict1 == 1) & (df.switch_count_ses == 1), "amb_switch_bloc"] = 1
    df["multiswitch"] = 0
    df.loc[df.switch_count_ses > 1, "multiswitch"] = 1

    # --- career switch total (do 124-126) ---
    df = df.drop(columns=["switch_count_total"])
    df["switch_count_total"] = df.groupby("hoy_id")["switch_count_ses"].transform("sum")

    # --- intensity (do 145-150) ---
    df["intensity2"] = np.sqrt(df["dw_nomd1"]**2 + df["dw_nomd2"]**2)
    df["z_intense2"] = (df["intensity2"] - df["intensity2"].mean()) / df["intensity2"].std(ddof=1)

    # --- delegation id bloc_id3 (do 155-167) ---
    miss = df["parlgov_partyid"].isna()
    max_bloc = df.loc[miss].groupby(["ms", "nationalparty"])["bloc_id"].transform("max") + 10000
    df["bloc_id3"] = df["parlgov_partyid"]
    df.loc[miss, "bloc_id3"] = df.loc[miss].index.map(max_bloc)
    df.loc[df["bloc_id"].isna(), "bloc_id3"] = 10000
    # bloc_tag3 = tag(EP bloc_id3): 1 on first occurrence of each (EP, bloc_id3)
    df = df.sort_values(["hoy_id", "EP", "start_group", "ms", "bloc_id3"], kind="stable")
    df["bloc_tag3"] = (~df.duplicated(["EP", "bloc_id3"])).astype(int)

    return df
