"""Validate the exactly-reproducible Party Politics components:
 - data pipeline (dataset_12222020 -> PP_dataset), all columns
 - Firth session_switch models (Table 5 robustness) vs march25_2021.log
The multilevel (xtmelogit) Tables 4/5 are NOT validated here - see
make_pp_multilevel.R; they cannot be reproduced bit-exact without Stata.
"""
import warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
from pp import config, stage, results

FIRTH_TRUTH = {  # penalized log-likelihood from march25_2021.log
    "as_firth_intense": -643.86901,
    "as_firth_quad":    -568.22092,
    "as_firth_full":    -556.95429,
}

def main():
    raw = pd.read_csv(config.RAW_INPUT, low_memory=False)
    ref = pd.read_csv(config.PP_REF, low_memory=False)
    got = stage.run(raw)
    key = ["hoy_id", "EP", "start_group", "end_group", "bloc_id"]
    g = got.set_index(key).sort_index(); r = ref.set_index(key).sort_index()
    ix = g.index.intersection(r.index); g, r = g.loc[ix], r.loc[ix]
    ok = tot = 0
    for c in [x for x in r.columns if x in g.columns]:
        a, b = g[c], r[c]
        if a.dtype.kind in "fi" and b.dtype.kind in "fi":
            d = (a.astype(float)-b.astype(float)).abs(); rel = d/b.astype(float).abs().replace(0, np.nan)
            m = (d <= 1e-3) | (rel <= 1e-4) | (a.isna() & b.isna())
        else:
            m = (a.astype("string") == b.astype("string")) | (a.isna() & b.isna())
        ok += int(m.sum()); tot += len(a)
    lines = ["# Party Politics validation", "",
             f"## Data pipeline (dataset_12222020 -> PP_dataset)",
             f"- {ok}/{tot} cells match across {len([x for x in r.columns if x in g.columns])} columns, {len(g)} rows -> {100*ok/tot:.3f}%",
             "", "## Firth session_switch models (Table 5 robustness) vs march25_2021.log"]
    ft = results.firth_table(got)
    npass = 0
    for name, LL in FIRTH_TRUTH.items():
        m = ft[name]; good = abs(m["loglik"]-LL) < 1e-2 and m["n"] == 3977
        npass += good
        lines.append(f"- {'OK ' if good else 'FAIL'} {name}: N={m['n']} logLik*={m['loglik']:.5f} (stata {LL})")
    lines += ["", f"## Firth: {npass}/{len(FIRTH_TRUTH)} match",
              "", "## Multilevel Tables 4/5 (xtmelogit) - see output/multilevel_findings.md",
              "- Reported models are THREE-LEVEL NESTED: || start_group_num: || bloc_id3:",
              "  (lme4: (1 | start_group_num/bloc_id3)).",
              "- Exact Stata coefficients are preserved in march25_2021.log (recoverable",
              "  at full precision). Independent Python reproduction did not succeed here",
              "  (nested quadrature too heavy for the sandbox; models numerically delicate).",
              "- Corrected R/lme4 script: make_pp_multilevel.R (run in RStudio)."]
    (config.OUT / "validation_report.md").write_text("\n".join(lines))
    print("\n".join(lines))

if __name__ == "__main__":
    main()
