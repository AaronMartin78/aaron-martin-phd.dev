"""Party Politics results: exactly-reproducible models (Firth + plain logit).

The multilevel (xtmelogit) models that make up Tables 4 & 5 are handled
separately via generated R/lme4 scripts (see make_r_scripts.py), because no
tool available here reproduces Stata's quadrature exactly.
"""
from __future__ import annotations
import numpy as np, pandas as pd


def _firth_fit(X, y, free):
    p = X.shape[1]; beta = np.zeros(p); free = np.asarray(free)
    for _ in range(300):
        eta = X @ beta; pr = 1/(1+np.exp(-eta)); W = pr*(1-pr)
        XtWX = X.T @ (X*W[:, None]); Minv = np.linalg.inv(XtWX)
        Q = np.einsum("ij,jk,ik->i", X, Minv, X); h = W*Q
        U = X.T @ (y - pr + h*(0.5-pr))
        step = np.linalg.solve(XtWX[np.ix_(free, free)], U[free]); beta[free] += step
        if np.max(np.abs(step)) < 1e-10:
            break
    pll = float(np.sum(y*np.log(pr) + (1-y)*np.log(1-pr)) + 0.5*np.log(np.linalg.det(XtWX)))
    se = np.full(p, np.nan); se[free] = np.sqrt(np.diag(np.linalg.inv(XtWX[np.ix_(free, free)])))
    return beta, se, pll


def _design(d, xs):
    """Add quadratic/interaction helper columns referenced by name."""
    d = d.copy()
    if "a1sq" in xs: d["a1sq"] = d["a1_std2"]**2
    if "a2sq" in xs: d["a2sq"] = d["a2_std2"]**2
    if "a1a2" in xs: d["a1a2"] = d["a1_std2"]*d["a2_std2"]
    return d


def firth(df, dv, xs):
    d = _design(df, xs)[[dv] + xs].apply(pd.to_numeric, errors="coerce").dropna()
    X = np.column_stack([np.ones(len(d)), d[xs].values]); y = d[dv].values.astype(float)
    beta, se, pll = _firth_fit(X, y, np.arange(X.shape[1]))
    cols = ["_cons"] + xs
    return dict(n=len(d), loglik=pll, coef=dict(zip(cols, beta)), bse=dict(zip(cols, se)))


# Table 5 (ambitious switch) Firth robustness models, as run in march25_2021.log
FIRTH_MODELS = {
    "as_firth_intense": ("session_switch",
        ["collapse", "z_intense2", "c_npd_perc", "c_epg_perc", "govt2", "mep_tenure", "age_martin", "female"]),
    "as_firth_quad": ("session_switch",
        ["collapse", "a1_std2", "a2_std2", "a1sq", "a2sq", "c_npd_perc", "c_epg_perc", "govt2", "mep_tenure", "age_martin", "female"]),
    "as_firth_full": ("session_switch",
        ["collapse", "a1_std2", "a2_std2", "a1sq", "a2sq", "a1a2", "c_npd_perc", "c_epg_perc", "govt2", "mep_tenure", "age_martin", "female"]),
}


def firth_table(df):
    return {name: firth(df, dv, xs) for name, (dv, xs) in FIRTH_MODELS.items()}


def logit(df, dv, xs, cluster=None):
    """Plain logistic regression (statsmodels); optional clustered SEs."""
    import statsmodels.api as sm
    d = _design(df, xs)[[dv] + xs + ([cluster] if cluster else [])].apply(pd.to_numeric, errors="coerce").dropna()
    X = sm.add_constant(d[xs]); y = d[dv]
    if cluster:
        res = sm.Logit(y, X).fit(disp=0, cov_type="cluster", cov_kwds={"groups": d[cluster]})
    else:
        res = sm.Logit(y, X).fit(disp=0)
    ren = lambda k: "_cons" if k == "const" else k
    return dict(n=int(res.nobs), loglik=float(res.llf),
                coef={ren(k): v for k, v in res.params.items()},
                bse={ren(k): v for k, v in res.bse.items()})
