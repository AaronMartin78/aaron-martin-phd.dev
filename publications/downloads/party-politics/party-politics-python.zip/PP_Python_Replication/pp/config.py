import os
from pathlib import Path
DATA = Path(os.environ.get("PP_DATA_ROOT", Path(__file__).resolve().parents[2]))
CONVERTED = DATA / "Converted Data Files"
RAW_INPUT = CONVERTED / "dataset_12222020.csv"
PP_REF    = CONVERTED / "PP_dataset.csv"
BASE = DATA / "reference"
DO_FILE  = BASE / "PP_20210325.do"
LOG_FILE = BASE / "march25_2021.log"
OUT = Path(__file__).resolve().parents[1] / "output"; OUT.mkdir(parents=True, exist_ok=True)
