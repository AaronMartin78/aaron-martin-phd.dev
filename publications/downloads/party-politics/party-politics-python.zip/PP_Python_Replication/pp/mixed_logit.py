"""Random-intercept mixed logit via Gauss-Hermite quadrature.

An approximation to Stata's `xtmelogit ... || group:` for the Party Politics
Tables 4/5. It maximizes the same marginal likelihood Stata does (integrating a
normal random intercept out of a logit), so fixed-effect estimates should land
close - but it is NOT guaranteed bit-identical (different quadrature/optimizer).
"""
from __future__ import annotations
import numpy as np, pandas as pd
from numpy.polynomial.hermite import hermgauss
from scipy.optimize import minimize
from scipy.special import logsumexp
import statsmodels.api as sm

_C = 0.5 * np.log(np.pi)   # normalizing constant for physicists' Hermite -> N(0,1)
_S2 = np.sqrt(2.0)


def fit(df, dv, xs, group="start_group_num", nquad=24):
    d = df[[dv, group] + xs].apply(pd.to_numeric, errors="coerce").dropna()
    y = d[dv].values.astype(float)
    X = np.column_stack([np.ones(len(d)), d[xs].values])
    g = pd.factorize(d[group])[0]
    G = int(g.max() + 1)
    nodes, wts = hermgauss(nquad)
    logw = np.log(wts) - _C                        # weight in log-space for E[.] under N(0,1)
    start = np.asarray(sm.Logit(y, X).fit(disp=0).params)

    def negll(par):
        b = par[:X.shape[1]]; sig = np.exp(par[-1])
        eta = (X @ b)[:, None] + sig * _S2 * nodes[None, :]      # obs x nodes
        # log Bernoulli lik per obs per node
        L = np.where(y[:, None] == 1, -np.logaddexp(0, -eta), -np.logaddexp(0, eta))
        S = np.zeros((G, nquad))
        np.add.at(S, g, L)                                       # sum over obs within group
        grp_ll = logsumexp(S + logw[None, :], axis=1)           # log E_u[ prod lik ]
        return -grp_ll.sum()

    r = minimize(negll, np.append(start, np.log(0.7)), method="L-BFGS-B",
                 options={"maxiter": 400})
    b = r.x[:X.shape[1]]
    return dict(coef=dict(zip(["_cons"] + xs, b)), sigma=float(np.exp(r.x[-1])),
                n=len(d), G=G, loglik=float(-r.fun), converged=bool(r.success))
